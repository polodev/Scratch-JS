chrome.devtools.panels.create(
  'Scratch JS',
  'art/48.png',
  'panel/repl.html'
);
